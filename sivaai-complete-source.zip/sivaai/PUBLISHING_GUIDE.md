# Siva.AI — Complete Publishing Guide
## Play Store + App Store + Website

---

## STEP 1 — Set up developer accounts

### Google Play Store (Android)
1. Go to https://play.google.com/console
2. Pay one-time $25 USD registration fee
3. Complete identity verification (takes 2–3 days)
4. Accept Developer Distribution Agreement

### Apple App Store (iOS)
1. Go to https://developer.apple.com/programs/
2. Pay $99 USD/year
3. Verify with Apple ID + D-U-N-S number
4. Enroll in Apple Developer Program (takes 1–5 days)

---

## STEP 2 — Build the APK / AAB (Android)

```bash
# 1. Install dependencies
cd SivaAI
npm install

# 2. Generate a signing keystore (KEEP THIS FILE SAFE FOREVER)
keytool -genkey -v \
  -keystore sivaai-release.keystore \
  -alias sivaai \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000

# 3. Add to android/gradle.properties:
MYAPP_UPLOAD_STORE_FILE=sivaai-release.keystore
MYAPP_UPLOAD_KEY_ALIAS=sivaai
MYAPP_UPLOAD_STORE_PASSWORD=YOUR_STORE_PASSWORD
MYAPP_UPLOAD_KEY_PASSWORD=YOUR_KEY_PASSWORD

# 4. Build Android App Bundle (AAB) — required for Play Store
cd android
./gradlew bundleRelease

# Output: android/app/build/outputs/bundle/release/app-release.aab

# 5. Build APK (for direct download / sideloading)
./gradlew assembleRelease
# Output: android/app/build/outputs/apk/release/app-release.apk
```

---

## STEP 3 — Build IPA (iOS)

```bash
# 1. Install pods
cd ios && pod install && cd ..

# 2. Open Xcode
open ios/SivaAI.xcworkspace

# 3. Set Bundle ID: ai.siva.app
# 4. Set Team: Your Apple Developer Team
# 5. Product → Archive
# 6. Distribute App → App Store Connect
```

---

## STEP 4 — Play Store submission

1. Log in to https://play.google.com/console
2. Create app → App name: "Siva.AI"
3. Fill in:
   - **Category:** Productivity / Communication
   - **Content rating:** complete questionnaire
   - **Target audience:** 18+
4. Upload AAB file
5. Add store listing:
   - Short description (80 chars): "AI call screening — blocks spam, screens unknown callers"
   - Full description (4000 chars): see template below
   - Screenshots: at least 2 phone screenshots
   - Feature graphic: 1024×500px
   - App icon: 512×512px (PNG, no alpha)
6. Set pricing: Free (with optional in-app Pro subscription)
7. Submit for review → typically 3–7 days

### Play Store description template:
```
Siva.AI is your intelligent AI call assistant that screens every unknown call, blocks spam automatically, and lets you take over instantly when it matters.

✨ KEY FEATURES:
• AI Call Screening — Siva answers unknown calls, transcribes in real time
• Call Takeover — jump in with one tap, Siva steps back
• AI Assist Buttons — Whisper Reply, Translate, Stall Caller, Auto-Schedule
• Male & Female Voice — choose from 6 voices including Telugu accents
• Smart Memory — Siva remembers your contacts and their intent
• Fraud Detection — catches fake government calls, phishing attempts
• Analytics — full breakdown of your call patterns

🔒 PRIVACY FIRST:
All call data stored locally on your phone. You own your data.
```

---

## STEP 5 — App Store submission (iOS)

1. Log in to https://appstoreconnect.apple.com
2. New App → iOS, Bundle ID: ai.siva.app
3. Fill in metadata (same as Play Store)
4. Upload IPA via Xcode or Transporter app
5. Submit for review → typically 1–3 days

---

## STEP 6 — Website with direct APK download

### Option A: GitHub Pages (free)
```bash
# 1. Create repo: github.com/yourusername/sivaai-website
# 2. Upload app-release.apk to /downloads/
# 3. Enable GitHub Pages in repo settings
# 4. Users visit: yourusername.github.io/sivaai-website
```

### Option B: Custom domain (recommended)
1. Buy domain: sivaai.in (~₹800/year at GoDaddy or Namecheap)
2. Host on Hostinger / Netlify / Vercel (free tier available)
3. Upload APK to /public/downloads/SivaAI-latest.apk
4. Add download button:
```html
<a href="/downloads/SivaAI-latest.apk" download>
  Download Siva.AI APK
</a>
```
5. Add Play Store badge:
```html
<a href="https://play.google.com/store/apps/details?id=ai.siva.app">
  <img src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png" width="200" />
</a>
```

---

## STEP 7 — Backend (user data & auth)

### Recommended stack (free to start):
| Service         | Purpose                    | Free tier       |
|-----------------|----------------------------|-----------------|
| Firebase Auth   | OTP via SMS                | 10K SMS/month   |
| Firestore       | User profiles, call logs   | 1GB free        |
| Firebase Storage| Recordings backup          | 5GB free        |
| Render.com      | Node.js API server         | Free tier       |

### Firebase setup:
```bash
npm install @react-native-firebase/app @react-native-firebase/auth @react-native-firebase/firestore

# In AuthContext.js, replace sendOTP:
import auth from '@react-native-firebase/auth';
const sendOTP = async (phone) => {
  const confirmation = await auth().signInWithPhoneNumber(phone);
  return confirmation;
};
```

---

## STEP 8 — App store optimization (ASO)

**Keywords to target:** AI call assistant, spam call blocker, call screening, caller ID, unknown call screener, Telugu AI assistant

**Ratings strategy:**
- Prompt users for review after their 5th blocked spam call
- Use `react-native-rate` library

---

## COST SUMMARY

| Item                    | Cost              |
|-------------------------|-------------------|
| Google Play account     | $25 one-time      |
| Apple Developer account | $99/year          |
| Domain (sivaai.in)      | ~₹800/year        |
| Hosting (Netlify free)  | ₹0                |
| Firebase free tier      | ₹0                |
| **Total to launch**     | **~₹3,500**       |

---

## FILES CHECKLIST BEFORE SUBMISSION

- [ ] app-release.aab (Play Store)
- [ ] app-release.apk (direct download)
- [ ] App icon 512×512px
- [ ] Feature graphic 1024×500px
- [ ] 4 screenshots (minimum)
- [ ] Privacy policy URL (required)
- [ ] sivaai-release.keystore (BACKUP IN 2 PLACES!)
