/**
 * Siva.AI — PermissionsManager.js
 * Handles all runtime permissions for Android & iOS
 * Including: Phone, Storage (internal), Microphone, Notifications, Contacts
 */

import { Platform, Alert } from 'react-native';
import {
  check, request, requestMultiple, PERMISSIONS, RESULTS
} from 'react-native-permissions';
import RNFS from 'react-native-fs';

// Internal storage path for Siva.AI data
export const SIVA_DIR = RNFS.ExternalStorageDirectoryPath + '/SivaAI';
export const SIVA_RECORDINGS_DIR = SIVA_DIR + '/Recordings';
export const SIVA_LOGS_DIR = SIVA_DIR + '/Logs';
export const SIVA_EXPORTS_DIR = SIVA_DIR + '/Exports';

const PermissionsManager = {

  /**
   * requestAll — requests all required permissions at once
   * Called during onboarding (ProfileSetupScreen step 3)
   */
  requestAll: async () => {
    const androidPerms = [
      PERMISSIONS.ANDROID.READ_PHONE_STATE,
      PERMISSIONS.ANDROID.CALL_PHONE,
      PERMISSIONS.ANDROID.ANSWER_PHONE_CALLS,
      PERMISSIONS.ANDROID.READ_CALL_LOG,
      PERMISSIONS.ANDROID.WRITE_CALL_LOG,
      PERMISSIONS.ANDROID.RECORD_AUDIO,
      PERMISSIONS.ANDROID.READ_CONTACTS,
      PERMISSIONS.ANDROID.POST_NOTIFICATIONS,
    ];

    // Android 13+ uses granular media permissions instead of WRITE_EXTERNAL_STORAGE
    const storagePerms = Platform.Version >= 33
      ? [PERMISSIONS.ANDROID.READ_MEDIA_AUDIO, PERMISSIONS.ANDROID.READ_MEDIA_IMAGES]
      : [PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE, PERMISSIONS.ANDROID.WRITE_EXTERNAL_STORAGE];

    const iosPerms = [
      PERMISSIONS.IOS.MICROPHONE,
      PERMISSIONS.IOS.CONTACTS,
      PERMISSIONS.IOS.SPEECH_RECOGNITION,
    ];

    if (Platform.OS === 'android') {
      const results = await requestMultiple([...androidPerms, ...storagePerms]);
      console.log('[Perms] Android results:', results);
      await PermissionsManager.createStorageDirs();
      return results;
    } else {
      const results = await requestMultiple(iosPerms);
      console.log('[Perms] iOS results:', results);
      return results;
    }
  },

  /**
   * createStorageDirs — creates Siva.AI directories in internal storage
   * Structure:
   *   /storage/emulated/0/SivaAI/
   *     Recordings/   ← call recordings (mp3/m4a)
   *     Logs/         ← call logs JSON
   *     Exports/      ← user-exported data
   */
  createStorageDirs: async () => {
    try {
      const dirs = [SIVA_DIR, SIVA_RECORDINGS_DIR, SIVA_LOGS_DIR, SIVA_EXPORTS_DIR];
      for (const dir of dirs) {
        const exists = await RNFS.exists(dir);
        if (!exists) {
          await RNFS.mkdir(dir);
          console.log('[Storage] Created:', dir);
        }
      }
      // Write a .nomedia file to hide recordings from gallery
      const nomedia = SIVA_RECORDINGS_DIR + '/.nomedia';
      if (!(await RNFS.exists(nomedia))) {
        await RNFS.writeFile(nomedia, '', 'utf8');
      }
    } catch (e) {
      console.error('[Storage] createStorageDirs error:', e);
    }
  },

  /**
   * checkStoragePermission — single check for storage access
   */
  checkStoragePermission: async () => {
    if (Platform.OS === 'ios') return true;
    const perm = Platform.Version >= 33
      ? PERMISSIONS.ANDROID.READ_MEDIA_AUDIO
      : PERMISSIONS.ANDROID.WRITE_EXTERNAL_STORAGE;
    const result = await check(perm);
    return result === RESULTS.GRANTED;
  },

  /**
   * requestStorageOnly — used when user tries to play/save a recording
   * without having granted storage permission yet
   */
  requestStorageOnly: async () => {
    if (Platform.OS === 'ios') return true;
    const perm = Platform.Version >= 33
      ? PERMISSIONS.ANDROID.READ_MEDIA_AUDIO
      : PERMISSIONS.ANDROID.WRITE_EXTERNAL_STORAGE;
    const result = await request(perm);
    return result === RESULTS.GRANTED;
  },

  /**
   * checkMicPermission
   */
  checkMicPermission: async () => {
    const perm = Platform.OS === 'android'
      ? PERMISSIONS.ANDROID.RECORD_AUDIO
      : PERMISSIONS.IOS.MICROPHONE;
    const result = await check(perm);
    return result === RESULTS.GRANTED;
  },

  /**
   * saveRecordingToStorage — writes a call recording file to internal storage
   * @param {string} base64Data — base64-encoded audio
   * @param {string} filename — e.g. "call_20250602_1423.mp3"
   */
  saveRecordingToStorage: async (base64Data, filename) => {
    try {
      await PermissionsManager.createStorageDirs();
      const path = SIVA_RECORDINGS_DIR + '/' + filename;
      await RNFS.writeFile(path, base64Data, 'base64');
      console.log('[Storage] Recording saved:', path);
      return path;
    } catch (e) {
      console.error('[Storage] saveRecordingToStorage error:', e);
      throw e;
    }
  },

  /**
   * saveCallLogToStorage — appends call log entry as JSON
   */
  saveCallLogToStorage: async (callLog) => {
    try {
      await PermissionsManager.createStorageDirs();
      const path = SIVA_LOGS_DIR + '/calls.json';
      let logs = [];
      if (await RNFS.exists(path)) {
        const raw = await RNFS.readFile(path, 'utf8');
        logs = JSON.parse(raw);
      }
      logs.unshift({ ...callLog, savedAt: new Date().toISOString() });
      await RNFS.writeFile(path, JSON.stringify(logs.slice(0, 1000)), 'utf8');
    } catch (e) {
      console.error('[Storage] saveCallLogToStorage error:', e);
    }
  },

  /**
   * exportUserData — exports all user data as JSON to Exports/
   */
  exportUserData: async (userData) => {
    try {
      await PermissionsManager.createStorageDirs();
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      const path = SIVA_EXPORTS_DIR + `/siva_export_${ts}.json`;
      await RNFS.writeFile(path, JSON.stringify(userData, null, 2), 'utf8');
      Alert.alert('Exported', `Data saved to:\n${path}`);
      return path;
    } catch (e) {
      Alert.alert('Export failed', e.message);
    }
  },

  /**
   * deleteAllData — wipes all Siva.AI data from storage
   */
  deleteAllData: async () => {
    try {
      if (await RNFS.exists(SIVA_DIR)) {
        await RNFS.unlink(SIVA_DIR);
      }
      console.log('[Storage] All data deleted');
    } catch (e) {
      console.error('[Storage] deleteAllData error:', e);
    }
  },

  /**
   * getStorageUsage — returns total size of Siva.AI storage in MB
   */
  getStorageUsage: async () => {
    try {
      if (!(await RNFS.exists(SIVA_DIR))) return '0 MB';
      const items = await RNFS.readDir(SIVA_DIR);
      let totalBytes = 0;
      for (const item of items) {
        if (item.isFile()) totalBytes += item.size;
      }
      const mb = (totalBytes / (1024 * 1024)).toFixed(1);
      return `${mb} MB`;
    } catch {
      return '—';
    }
  },
};

export default PermissionsManager;
