/**
 * Siva.AI — AuthContext.js
 * Manages user auth state, AsyncStorage persistence, OTP simulation
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthContext = createContext(null);

const KEYS = {
  USER:    '@siva_user',
  PROFILE: '@siva_profile',
  TOKEN:   '@siva_token',
  CALLS:   '@siva_calls',
  MEMORY:  '@siva_memory',
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfileState] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadUser(); }, []);

  const loadUser = async () => {
    try {
      const [u, p] = await Promise.all([
        AsyncStorage.getItem(KEYS.USER),
        AsyncStorage.getItem(KEYS.PROFILE),
      ]);
      if (u) setUser(JSON.parse(u));
      if (p) setProfileState(JSON.parse(p));
    } catch (e) {
      console.error('AuthContext loadUser:', e);
    } finally {
      setLoading(false);
    }
  };

  /**
   * sendOTP — in production, call your backend API
   * POST /api/auth/send-otp  { phone }
   * Returns: { success: true, expiresIn: 300 }
   */
  const sendOTP = async (phone) => {
    // PRODUCTION: replace with real API call
    // const res = await fetch(`${API_BASE}/auth/send-otp`, {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ phone }),
    // });
    // if (!res.ok) throw new Error('OTP send failed');
    console.log('[Siva.AI] OTP sent to', phone);
    return { success: true };
  };

  /**
   * verifyOTP — validates code, returns isNewUser boolean
   * POST /api/auth/verify-otp  { phone, code }
   */
  const verifyOTP = async (phone, code) => {
    // PRODUCTION: real verification
    // const res = await fetch(`${API_BASE}/auth/verify-otp`, { ... });
    // const data = await res.json();

    // Simulation: any 6-digit code works in dev (test: 123456)
    if (code.length !== 6) throw new Error('Invalid OTP');

    const userData = { phone, verifiedAt: new Date().toISOString() };
    await AsyncStorage.setItem(KEYS.USER, JSON.stringify(userData));
    setUser(userData);

    const existingProfile = await AsyncStorage.getItem(KEYS.PROFILE);
    return !existingProfile; // true = new user → go to ProfileSetup
  };

  /**
   * saveProfile — persists name, gender, voice to AsyncStorage
   */
  const saveProfile = async (profileData) => {
    const fullProfile = {
      ...profileData,
      updatedAt: new Date().toISOString(),
    };
    await AsyncStorage.setItem(KEYS.PROFILE, JSON.stringify(fullProfile));
    setProfileState(fullProfile);

    // PRODUCTION: sync to backend
    // await fetch(`${API_BASE}/users/profile`, {
    //   method: 'PUT',
    //   headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    //   body: JSON.stringify(fullProfile),
    // });
  };

  /**
   * updateProfile — partial update
   */
  const updateProfile = async (updates) => {
    const current = profile || {};
    const merged = { ...current, ...updates, updatedAt: new Date().toISOString() };
    await AsyncStorage.setItem(KEYS.PROFILE, JSON.stringify(merged));
    setProfileState(merged);
  };

  /**
   * logout — clears all local user data
   */
  const logout = async () => {
    await AsyncStorage.multiRemove([KEYS.USER, KEYS.PROFILE, KEYS.TOKEN]);
    setUser(null);
    setProfileState(null);
  };

  /**
   * saveCallToStorage — appends a call record to local storage
   */
  const saveCallToStorage = async (callRecord) => {
    try {
      const existing = await AsyncStorage.getItem(KEYS.CALLS);
      const calls = existing ? JSON.parse(existing) : [];
      calls.unshift({ ...callRecord, id: Date.now().toString() });
      // keep last 500 calls
      const trimmed = calls.slice(0, 500);
      await AsyncStorage.setItem(KEYS.CALLS, JSON.stringify(trimmed));
    } catch (e) {
      console.error('saveCallToStorage:', e);
    }
  };

  /**
   * getCallHistory — retrieves stored calls
   */
  const getCallHistory = async () => {
    const raw = await AsyncStorage.getItem(KEYS.CALLS);
    return raw ? JSON.parse(raw) : [];
  };

  /**
   * saveMemory — saves a contact memory entry, deduped by phone
   */
  const saveMemory = async (entry) => {
    const raw = await AsyncStorage.getItem(KEYS.MEMORY);
    const memories = raw ? JSON.parse(raw) : [];
    const idx = memories.findIndex(m => m.phone === entry.phone);
    if (idx >= 0) {
      memories[idx] = { ...memories[idx], ...entry, updatedAt: new Date().toISOString() };
    } else {
      memories.unshift({ ...entry, createdAt: new Date().toISOString() });
    }
    await AsyncStorage.setItem(KEYS.MEMORY, JSON.stringify(memories));
  };

  return (
    <AuthContext.Provider value={{
      user, profile, loading,
      sendOTP, verifyOTP, saveProfile, updateProfile, logout,
      saveCallToStorage, getCallHistory, saveMemory,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
