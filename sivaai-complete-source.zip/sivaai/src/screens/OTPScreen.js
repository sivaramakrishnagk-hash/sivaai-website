/**
 * Siva.AI — OTPScreen.js
 * 6-digit OTP verification
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  StatusBar, KeyboardAvoidingView, Platform, ActivityIndicator, Alert
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const COLORS = {
  bg: '#0a0b0f', surface: '#111318', card: '#181c24',
  accent: '#6c63ff', accent2: '#00d4aa', text: '#f0f0f5',
  muted: '#8b8fa8', border: 'rgba(255,255,255,0.12)', error: '#ff6b6b',
};

export default function OTPScreen({ navigation, route }) {
  const { phone } = route.params;
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(30);
  const refs = Array(6).fill(null).map(() => useRef(null));
  const { verifyOTP } = useAuth();

  useEffect(() => {
    const t = setInterval(() => {
      setResendTimer(p => (p > 0 ? p - 1 : 0));
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const handleChange = (val, idx) => {
    const newOtp = [...otp];
    newOtp[idx] = val.replace(/\D/g, '').slice(-1);
    setOtp(newOtp);
    if (val && idx < 5) refs[idx + 1].current?.focus();
    if (newOtp.every(d => d !== '') && newOtp.join('').length === 6) {
      verifyCode(newOtp.join(''));
    }
  };

  const handleKeyPress = (e, idx) => {
    if (e.nativeEvent.key === 'Backspace' && !otp[idx] && idx > 0) {
      refs[idx - 1].current?.focus();
    }
  };

  const verifyCode = async (code) => {
    setLoading(true);
    try {
      const isNewUser = await verifyOTP(phone, code);
      if (isNewUser) {
        navigation.replace('ProfileSetup', { phone });
      } else {
        navigation.replace('Main');
      }
    } catch {
      Alert.alert('Invalid OTP', 'The code you entered is incorrect. Please try again.');
      setOtp(['', '', '', '', '', '']);
      refs[0].current?.focus();
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />
      <View style={styles.inner}>
        <TouchableOpacity style={styles.back} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>

        <View style={styles.logoBox}>
          <Text style={styles.logoLetter}>S</Text>
        </View>

        <Text style={styles.title}>Enter OTP</Text>
        <Text style={styles.sub}>
          We sent a 6-digit code to{'\n'}
          <Text style={styles.phone}>{phone}</Text>
        </Text>

        <View style={styles.otpRow}>
          {otp.map((digit, idx) => (
            <TextInput
              key={idx}
              ref={refs[idx]}
              style={[styles.otpBox, digit && styles.otpBoxFilled]}
              value={digit}
              onChangeText={v => handleChange(v, idx)}
              onKeyPress={e => handleKeyPress(e, idx)}
              keyboardType="number-pad"
              maxLength={1}
              selectTextOnFocus
            />
          ))}
        </View>

        {loading && (
          <ActivityIndicator color={COLORS.accent} size="large" style={{ marginVertical: 20 }} />
        )}

        <TouchableOpacity
          style={styles.resend}
          onPress={() => setResendTimer(30)}
          disabled={resendTimer > 0}
        >
          <Text style={[styles.resendText, resendTimer > 0 && styles.resendDim]}>
            {resendTimer > 0 ? `Resend OTP in ${resendTimer}s` : 'Resend OTP'}
          </Text>
        </TouchableOpacity>

        <Text style={styles.hint}>
          For testing, enter <Text style={{ color: COLORS.accent }}>123456</Text>
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.bg },
  inner: { flex: 1, padding: 24, justifyContent: 'center', alignItems: 'center' },
  back: { position: 'absolute', top: 52, left: 24 },
  backText: { color: COLORS.muted, fontSize: 14 },
  logoBox: {
    width: 56, height: 56, borderRadius: 14, backgroundColor: COLORS.accent,
    alignItems: 'center', justifyContent: 'center', marginBottom: 24
  },
  logoLetter: { fontSize: 24, fontWeight: '700', color: '#fff' },
  title: { fontSize: 24, fontWeight: '700', color: COLORS.text, marginBottom: 8 },
  sub: { fontSize: 14, color: COLORS.muted, textAlign: 'center', lineHeight: 22, marginBottom: 32 },
  phone: { color: COLORS.text, fontWeight: '600' },
  otpRow: { flexDirection: 'row', gap: 10, marginBottom: 28 },
  otpBox: {
    width: 46, height: 56, borderRadius: 12,
    borderWidth: 1.5, borderColor: COLORS.border,
    backgroundColor: COLORS.card,
    fontSize: 22, fontWeight: '700', color: COLORS.text,
    textAlign: 'center'
  },
  otpBoxFilled: { borderColor: COLORS.accent, backgroundColor: '#6c63ff18' },
  resend: { marginBottom: 16 },
  resendText: { fontSize: 13, color: COLORS.accent, fontWeight: '500' },
  resendDim: { color: COLORS.muted },
  hint: { fontSize: 11, color: COLORS.muted },
});
