/**
 * Siva.AI — LoginScreen.js
 * Phone number login with country code
 */

import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  StatusBar, KeyboardAvoidingView, Platform, ScrollView,
  ActivityIndicator, Alert, Image
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const COLORS = {
  bg: '#0a0b0f',
  surface: '#111318',
  card: '#181c24',
  accent: '#6c63ff',
  accent2: '#00d4aa',
  text: '#f0f0f5',
  muted: '#8b8fa8',
  border: 'rgba(255,255,255,0.12)',
  error: '#ff6b6b',
};

export default function LoginScreen({ navigation }) {
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const { sendOTP } = useAuth();

  const handleSendOTP = async () => {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length !== 10) {
      Alert.alert('Invalid number', 'Please enter a valid 10-digit mobile number.');
      return;
    }
    setLoading(true);
    try {
      await sendOTP('+91' + cleaned);
      navigation.navigate('OTP', { phone: '+91' + cleaned });
    } catch (e) {
      Alert.alert('Error', 'Could not send OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

        {/* Logo */}
        <View style={styles.logoWrap}>
          <View style={styles.logoBox}>
            <Text style={styles.logoLetter}>S</Text>
          </View>
          <Text style={styles.logoText}>Siva.AI</Text>
          <Text style={styles.tagline}>Your intelligent AI call assistant</Text>
        </View>

        {/* Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Welcome</Text>
          <Text style={styles.cardSub}>Enter your mobile number to continue</Text>

          <View style={styles.phoneRow}>
            <View style={styles.countryCode}>
              <Text style={styles.ccText}>🇮🇳 +91</Text>
            </View>
            <TextInput
              style={styles.phoneInput}
              placeholder="10-digit mobile number"
              placeholderTextColor={COLORS.muted}
              keyboardType="phone-pad"
              maxLength={10}
              value={phone}
              onChangeText={setPhone}
              returnKeyType="done"
              onSubmitEditing={handleSendOTP}
            />
          </View>

          <TouchableOpacity
            style={[styles.btn, loading && styles.btnDisabled]}
            onPress={handleSendOTP}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.btnText}>Send OTP →</Text>
            )}
          </TouchableOpacity>

          <Text style={styles.legal}>
            By continuing, you agree to Siva.AI's{' '}
            <Text style={styles.link}>Terms of Service</Text> and{' '}
            <Text style={styles.link}>Privacy Policy</Text>
          </Text>
        </View>

        {/* Features preview */}
        <View style={styles.features}>
          {[
            { icon: '🛡', label: 'AI call screening' },
            { icon: '🚫', label: 'Spam blocking' },
            { icon: '🎙', label: 'Voice assistant' },
            { icon: '🧠', label: 'Smart memory' },
          ].map((f, i) => (
            <View key={i} style={styles.featureItem}>
              <Text style={styles.featureIcon}>{f.icon}</Text>
              <Text style={styles.featureLabel}>{f.label}</Text>
            </View>
          ))}
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { flexGrow: 1, padding: 24, justifyContent: 'center' },
  logoWrap: { alignItems: 'center', marginBottom: 36 },
  logoBox: {
    width: 64, height: 64, borderRadius: 16,
    backgroundColor: COLORS.accent,
    alignItems: 'center', justifyContent: 'center', marginBottom: 12
  },
  logoLetter: { fontSize: 28, fontWeight: '700', color: '#fff' },
  logoText: {
    fontSize: 28, fontWeight: '700', color: COLORS.text,
    letterSpacing: -0.5
  },
  tagline: { fontSize: 13, color: COLORS.muted, marginTop: 4 },
  card: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    borderWidth: 0.5,
    borderColor: COLORS.border,
    padding: 20,
    marginBottom: 24
  },
  cardTitle: { fontSize: 20, fontWeight: '600', color: COLORS.text, marginBottom: 4 },
  cardSub: { fontSize: 13, color: COLORS.muted, marginBottom: 20 },
  phoneRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  countryCode: {
    backgroundColor: COLORS.surface,
    borderRadius: 10, borderWidth: 0.5, borderColor: COLORS.border,
    paddingHorizontal: 12, justifyContent: 'center'
  },
  ccText: { fontSize: 14, color: COLORS.text },
  phoneInput: {
    flex: 1, backgroundColor: COLORS.surface,
    borderRadius: 10, borderWidth: 0.5, borderColor: COLORS.border,
    paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 16, color: COLORS.text, letterSpacing: 1
  },
  btn: {
    backgroundColor: COLORS.accent, borderRadius: 12,
    paddingVertical: 14, alignItems: 'center', marginBottom: 16
  },
  btnDisabled: { opacity: 0.6 },
  btnText: { fontSize: 15, fontWeight: '600', color: '#fff' },
  legal: { fontSize: 11, color: COLORS.muted, textAlign: 'center', lineHeight: 18 },
  link: { color: COLORS.accent },
  features: {
    flexDirection: 'row', flexWrap: 'wrap',
    gap: 10, justifyContent: 'center'
  },
  featureItem: {
    backgroundColor: COLORS.card, borderRadius: 10,
    borderWidth: 0.5, borderColor: COLORS.border,
    padding: 12, alignItems: 'center', minWidth: '44%', flex: 1
  },
  featureIcon: { fontSize: 22, marginBottom: 4 },
  featureLabel: { fontSize: 11, color: COLORS.muted, textAlign: 'center' },
});
