/**
 * Siva.AI — ProfileSetupScreen.js
 * Collects: Full name, gender, preferred voice
 */

import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  StatusBar, ScrollView, ActivityIndicator, Alert
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../context/AuthContext';
import PermissionsManager from '../utils/PermissionsManager';

const COLORS = {
  bg: '#0a0b0f', surface: '#111318', card: '#181c24',
  accent: '#6c63ff', accent2: '#00d4aa', pink: '#d4537e',
  blue: '#4fc3f7', text: '#f0f0f5', muted: '#8b8fa8',
  border: 'rgba(255,255,255,0.12)', error: '#ff6b6b',
};

const VOICES = {
  female: [
    { id: 'aria',  name: 'Aria',  desc: 'Warm & friendly',    lang: 'English' },
    { id: 'nova',  name: 'Nova',  desc: 'Calm & clear',       lang: 'English' },
    { id: 'priya', name: 'Priya', desc: 'Telugu accent',       lang: 'Telugu' },
  ],
  male: [
    { id: 'siva_classic', name: 'Siva Classic', desc: 'Deep & confident', lang: 'English' },
    { id: 'rajan',        name: 'Rajan',        desc: 'Professional',     lang: 'English' },
    { id: 'arjun',        name: 'Arjun',        desc: 'Telugu accent',    lang: 'Telugu' },
  ],
};

export default function ProfileSetupScreen({ navigation, route }) {
  const { phone } = route.params;
  const { saveProfile } = useAuth();

  const [name, setName] = useState('');
  const [gender, setGender] = useState(null);       // 'male' | 'female' | 'other'
  const [selectedVoice, setSelectedVoice] = useState(null);
  const [step, setStep] = useState(1);              // 1 = name/gender, 2 = voice, 3 = permissions
  const [loading, setLoading] = useState(false);

  /* ── STEP 1 → 2 ── */
  const goToVoice = () => {
    if (!name.trim()) { Alert.alert('', 'Please enter your name'); return; }
    if (!gender) { Alert.alert('', 'Please select your gender'); return; }
    setSelectedVoice(null);
    setStep(2);
  };

  /* ── STEP 2 → 3 ── */
  const goToPermissions = () => {
    if (!selectedVoice) { Alert.alert('', 'Please choose a voice for Siva'); return; }
    setStep(3);
  };

  /* ── STEP 3 → FINISH ── */
  const finish = async () => {
    setLoading(true);
    try {
      await PermissionsManager.requestAll();
      const profile = {
        phone,
        name: name.trim(),
        gender,
        voice: selectedVoice,
        createdAt: new Date().toISOString(),
      };
      await saveProfile(profile);
      navigation.replace('Main');
    } catch (e) {
      Alert.alert('Error', 'Could not save profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const voiceList = gender === 'male' ? VOICES.male
                  : gender === 'female' ? VOICES.female
                  : [...VOICES.female, ...VOICES.male];

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      {/* Progress bar */}
      <View style={styles.progress}>
        {[1,2,3].map(s => (
          <View key={s} style={[styles.progDot, step >= s && styles.progActive,
            s === 1 && { borderTopLeftRadius: 99, borderBottomLeftRadius: 99 },
            s === 3 && { borderTopRightRadius: 99, borderBottomRightRadius: 99 }
          ]} />
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

        {/* ─── STEP 1: Name & Gender ─── */}
        {step === 1 && (
          <View>
            <Text style={styles.stepLabel}>Step 1 of 3</Text>
            <Text style={styles.title}>Tell us about yourself</Text>
            <Text style={styles.sub}>This helps Siva personalise your experience</Text>

            <Text style={styles.label}>Your full name</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. Siva Kumar"
              placeholderTextColor={COLORS.muted}
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
              returnKeyType="next"
            />

            <Text style={styles.label}>Gender</Text>
            <View style={styles.genderRow}>
              {[
                { id: 'female', label: 'Female', icon: '👩' },
                { id: 'male',   label: 'Male',   icon: '👨' },
                { id: 'other',  label: 'Other',  icon: '🧑' },
              ].map(g => (
                <TouchableOpacity
                  key={g.id}
                  style={[styles.genderCard,
                    gender === g.id && styles.genderCardActive,
                    gender === g.id && g.id === 'female' && { borderColor: COLORS.pink },
                    gender === g.id && g.id === 'male'   && { borderColor: COLORS.blue },
                  ]}
                  onPress={() => setGender(g.id)}
                  activeOpacity={0.8}
                >
                  <Text style={styles.genderIcon}>{g.icon}</Text>
                  <Text style={[styles.genderLabel, gender === g.id && { color: COLORS.text }]}>
                    {g.label}
                  </Text>
                  {gender === g.id && (
                    <View style={styles.checkBadge}>
                      <Text style={styles.checkText}>✓</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={styles.btn} onPress={goToVoice} activeOpacity={0.85}>
              <Text style={styles.btnText}>Continue →</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ─── STEP 2: Voice ─── */}
        {step === 2 && (
          <View>
            <Text style={styles.stepLabel}>Step 2 of 3</Text>
            <Text style={styles.title}>Choose Siva's voice</Text>
            <Text style={styles.sub}>This is the voice Siva will use on all your calls</Text>

            {voiceList.map(v => (
              <TouchableOpacity
                key={v.id}
                style={[styles.voiceCard,
                  selectedVoice?.id === v.id && styles.voiceCardActive
                ]}
                onPress={() => setSelectedVoice(v)}
                activeOpacity={0.8}
              >
                <View style={[styles.voiceAvatar,
                  { backgroundColor: VOICES.female.find(f=>f.id===v.id) ? '#d4537e20' : '#4fc3f720' }
                ]}>
                  <Text style={{ fontSize: 20 }}>
                    {VOICES.female.find(f=>f.id===v.id) ? '👩' : '👨'}
                  </Text>
                </View>
                <View style={styles.voiceInfo}>
                  <Text style={styles.voiceName}>{v.name}</Text>
                  <Text style={styles.voiceDesc}>{v.desc} · {v.lang}</Text>
                </View>
                {selectedVoice?.id === v.id ? (
                  <View style={styles.voiceCheck}>
                    <Text style={styles.voiceCheckText}>✓</Text>
                  </View>
                ) : (
                  <Text style={styles.playIcon}>▶</Text>
                )}
              </TouchableOpacity>
            ))}

            <View style={styles.rowBtns}>
              <TouchableOpacity style={styles.btnOutline} onPress={() => setStep(1)}>
                <Text style={styles.btnOutlineText}>← Back</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, { flex: 1 }]} onPress={goToPermissions}>
                <Text style={styles.btnText}>Continue →</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ─── STEP 3: Permissions ─── */}
        {step === 3 && (
          <View>
            <Text style={styles.stepLabel}>Step 3 of 3</Text>
            <Text style={styles.title}>Allow permissions</Text>
            <Text style={styles.sub}>
              Siva needs these to work. All data stays on your phone or encrypted on our servers.
            </Text>

            {[
              { icon: '📞', title: 'Phone calls',       desc: 'To screen and answer calls for you',      req: true  },
              { icon: '💾', title: 'Storage',            desc: 'To save call recordings & your data locally', req: true  },
              { icon: '🎙', title: 'Microphone',         desc: 'For voice commands and call takeover',    req: true  },
              { icon: '📩', title: 'Notifications',      desc: 'To alert you about important calls',      req: true  },
              { icon: '📋', title: 'Read phone state',   desc: 'To detect incoming calls automatically',  req: true  },
              { icon: '📍', title: 'Contacts (optional)','desc': 'To identify your saved contacts',        req: false },
            ].map((p, i) => (
              <View key={i} style={styles.permCard}>
                <Text style={styles.permIcon}>{p.icon}</Text>
                <View style={styles.permInfo}>
                  <View style={styles.permTitleRow}>
                    <Text style={styles.permTitle}>{p.title}</Text>
                    {p.req && <View style={styles.reqBadge}><Text style={styles.reqText}>Required</Text></View>}
                  </View>
                  <Text style={styles.permDesc}>{p.desc}</Text>
                </View>
              </View>
            ))}

            <View style={styles.storageNote}>
              <Text style={styles.storageNoteText}>
                📱 Siva stores call recordings and your profile in your phone's internal storage at{' '}
                <Text style={{ color: COLORS.accent }}>/storage/emulated/0/SivaAI/</Text>.
                You can view, export, or delete this anytime from Settings.
              </Text>
            </View>

            <View style={styles.rowBtns}>
              <TouchableOpacity style={styles.btnOutline} onPress={() => setStep(2)}>
                <Text style={styles.btnOutlineText}>← Back</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.btn, { flex: 1, backgroundColor: COLORS.accent2 }, loading && { opacity: 0.6 }]}
                onPress={finish}
                disabled={loading}
              >
                {loading
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={styles.btnText}>Allow & Start →</Text>
                }
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.bg },
  progress: { flexDirection: 'row', margin: 20, marginTop: 52, gap: 4 },
  progDot: { flex: 1, height: 3, backgroundColor: COLORS.border },
  progActive: { backgroundColor: COLORS.accent },
  scroll: { padding: 24, paddingTop: 8 },
  stepLabel: { fontSize: 11, color: COLORS.accent, fontWeight: '600', letterSpacing: 0.5, marginBottom: 8 },
  title: { fontSize: 22, fontWeight: '700', color: COLORS.text, marginBottom: 6 },
  sub: { fontSize: 13, color: COLORS.muted, marginBottom: 24, lineHeight: 20 },
  label: { fontSize: 12, color: COLORS.muted, marginBottom: 8, fontWeight: '500' },
  input: {
    backgroundColor: COLORS.card, borderRadius: 12, borderWidth: 0.5,
    borderColor: COLORS.border, padding: 14, fontSize: 16,
    color: COLORS.text, marginBottom: 20
  },
  genderRow: { flexDirection: 'row', gap: 10, marginBottom: 24 },
  genderCard: {
    flex: 1, backgroundColor: COLORS.card, borderRadius: 12,
    borderWidth: 1.5, borderColor: COLORS.border,
    padding: 14, alignItems: 'center', position: 'relative'
  },
  genderCardActive: { borderColor: COLORS.accent, backgroundColor: '#6c63ff12' },
  genderIcon: { fontSize: 26, marginBottom: 6 },
  genderLabel: { fontSize: 12, color: COLORS.muted, fontWeight: '500' },
  checkBadge: {
    position: 'absolute', top: 6, right: 6,
    width: 16, height: 16, borderRadius: 8,
    backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center'
  },
  checkText: { color: '#fff', fontSize: 9, fontWeight: '700' },
  btn: {
    backgroundColor: COLORS.accent, borderRadius: 12,
    paddingVertical: 14, alignItems: 'center', marginBottom: 12
  },
  btnText: { fontSize: 15, fontWeight: '600', color: '#fff' },
  btnOutline: {
    borderRadius: 12, borderWidth: 1, borderColor: COLORS.border,
    paddingVertical: 14, paddingHorizontal: 20, alignItems: 'center', marginBottom: 12
  },
  btnOutlineText: { fontSize: 14, color: COLORS.muted },
  rowBtns: { flexDirection: 'row', gap: 10, marginTop: 8 },
  voiceCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: COLORS.card, borderRadius: 12,
    borderWidth: 1.5, borderColor: COLORS.border,
    padding: 14, marginBottom: 10
  },
  voiceCardActive: { borderColor: COLORS.accent, backgroundColor: '#6c63ff12' },
  voiceAvatar: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  voiceInfo: { flex: 1 },
  voiceName: { fontSize: 14, fontWeight: '600', color: COLORS.text, marginBottom: 2 },
  voiceDesc: { fontSize: 11, color: COLORS.muted },
  voiceCheck: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center'
  },
  voiceCheckText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  playIcon: { fontSize: 14, color: COLORS.muted },
  permCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12,
    backgroundColor: COLORS.card, borderRadius: 12,
    borderWidth: 0.5, borderColor: COLORS.border,
    padding: 14, marginBottom: 10
  },
  permIcon: { fontSize: 22, marginTop: 2 },
  permInfo: { flex: 1 },
  permTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 3 },
  permTitle: { fontSize: 13, fontWeight: '600', color: COLORS.text },
  reqBadge: { backgroundColor: '#6c63ff20', borderRadius: 6, paddingHorizontal: 6, paddingVertical: 1 },
  reqText: { fontSize: 9, color: COLORS.accent, fontWeight: '600' },
  permDesc: { fontSize: 11, color: COLORS.muted, lineHeight: 17 },
  storageNote: {
    backgroundColor: '#6c63ff10', borderRadius: 10, borderWidth: 0.5,
    borderColor: '#6c63ff30', padding: 12, marginBottom: 20
  },
  storageNoteText: { fontSize: 11, color: COLORS.muted, lineHeight: 18 },
});
