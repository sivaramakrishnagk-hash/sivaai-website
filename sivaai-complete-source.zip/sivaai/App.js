/**
 * Siva.AI — Production React Native App
 * Entry point with navigation stack
 */

import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SplashScreen from './src/screens/SplashScreen';
import LoginScreen from './src/screens/LoginScreen';
import OTPScreen from './src/screens/OTPScreen';
import ProfileSetupScreen from './src/screens/ProfileSetupScreen';
import MainTabNavigator from './src/navigation/MainTabNavigator';
import { AuthProvider } from './src/context/AuthContext';
import { VoiceProvider } from './src/context/VoiceContext';
import { PermissionsProvider } from './src/context/PermissionsContext';

const Stack = createNativeStackNavigator();

export default function App() {
  const [initialRoute, setInitialRoute] = useState(null);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const user = await AsyncStorage.getItem('@siva_user');
      if (user) {
        setInitialRoute('Main');
      } else {
        setInitialRoute('Login');
      }
    } catch {
      setInitialRoute('Login');
    }
  };

  if (!initialRoute) return <SplashScreen />;

  return (
    <AuthProvider>
      <VoiceProvider>
        <PermissionsProvider>
          <NavigationContainer>
            <Stack.Navigator
              initialRouteName={initialRoute}
              screenOptions={{ headerShown: false }}
            >
              <Stack.Screen name="Login" component={LoginScreen} />
              <Stack.Screen name="OTP" component={OTPScreen} />
              <Stack.Screen name="ProfileSetup" component={ProfileSetupScreen} />
              <Stack.Screen name="Main" component={MainTabNavigator} />
            </Stack.Navigator>
          </NavigationContainer>
        </PermissionsProvider>
      </VoiceProvider>
    </AuthProvider>
  );
}
